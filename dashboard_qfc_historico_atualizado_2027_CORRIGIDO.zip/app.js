let D;
const $=s=>document.querySelector(s);
const norm=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const val=(o,k)=>o&&o[k]!==''&&o[k]!=null?esc(o[k]):'—';
function photo(n){
  const name=typeof n==='object' ? n?.ATLETA : n;
  if(n&&typeof n==='object'&&n.FOTO) return n.FOTO;
  if(n&&typeof n==='object'&&n._FOTO) return n._FOTO;
  return D?.photoMap?.[name]||'';
}
function pic(n,cls='avatar'){
  let p=photo(n);
  return p?`<img class="${cls}" src="${p}" alt="${esc(typeof n==='object'?n?.ATLETA:n)}">`:`<div class="${cls} placeholder">${esc(String(typeof n==='object'?n?.ATLETA:n||'?').slice(0,1))}</div>`;
}
function counts(){let e=D.elenco;return {total:e.length,tit:e.filter(x=>x.STATUS==='Titular').length,active:e.filter(x=>x.STATUS==='Ativo').length,rot:e.filter(x=>x.STATUS==='Rotação').length,trans:e.filter(x=>x.STATUS==='Transição').length}}
function renderOverview(){let e=D.elenco,c=counts(),m={};e.forEach(x=>m[x.POSIÇÃO]=(m[x.POSIÇÃO]||0)+1);let max=Math.max(...Object.values(m));$('#overview').innerHTML=`<div class="cards six"><div class="card"><div class="label">Atletas</div><div class="value">${c.total}</div></div><div class="card"><div class="label">Titulares</div><div class="value">${c.tit}</div></div><div class="card"><div class="label">Ativos</div><div class="value">${c.active}</div></div><div class="card"><div class="label">Rotação</div><div class="value">${c.rot}</div></div><div class="card"><div class="label">Transição</div><div class="value">${c.trans}</div></div><div class="card"><div class="label">Lesionados</div><div class="value">0</div></div></div><div class="grid2"><div class="panel"><div class="section-head"><h2>Atletas por posição</h2><span>${c.total} atletas</span></div><div class="position-chart">${Object.entries(m).map(([k,v])=>`<div class="position-chart-row"><div class="position-chart-label">${esc(k)}</div><div class="position-chart-track"><div class="position-chart-bar" style="width:${v/max*100}%"></div></div><div class="position-chart-value">${v}</div></div>`).join('')}</div></div><div class="panel"><div class="section-head"><h2>Status do elenco</h2><span>Atual</span></div><div class="status-grid">${['Titular','Ativo','Rotação','Transição'].map(s=>`<div class="status"><b>${e.filter(x=>x.STATUS===s).length}</b><span>${s}</span></div>`).join('')}</div><div class="small-note">Lesões e demais ocorrências serão refletidas conforme os campos do controle técnico forem preenchidos.</div></div></div><div class="panel" style="margin-top:18px"><div class="section-head"><h2>Elenco · visão rápida</h2><span>${c.total} atletas</span></div><div class="athletes">${e.map(r=>`<div class="athlete"><div class="athlete-top">${pic(r)}<div><div class="athlete-name">${esc(r.ATLETA)}</div><div class="muted">${esc(r.POSIÇÃO)} · ${esc(r.PÉ)}</div></div></div><span class="badge">${esc(r.STATUS)}</span></div>`).join('')}</div></div>`}
function renderSquad(){let e=D.elenco;$('#squad').innerHTML=`<div class="panel"><div class="filterbar"><div class="field"><label>Buscar atleta</label><input id="s" placeholder="Nome..."></div><div class="field"><label>Posição</label><select id="p"><option value="">Todas</option>${[...new Set(e.map(x=>x.POSIÇÃO))].map(x=>`<option>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>Pé</label><select id="foot"><option value="">Todos</option>${[...new Set(e.map(x=>x.PÉ))].map(x=>`<option>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>Status</label><select id="st"><option value="">Todos</option>${[...new Set(e.map(x=>x.STATUS))].map(x=>`<option>${esc(x)}</option>`).join('')}</select></div><div class="field"><label>Atividade</label><select id="act"><option value="">Todos</option><option value="ativo">Ativos</option><option value="inativo">Inativos</option></select></div></div><div id="stbl"></div></div>`;function draw(){let q=$('#s').value.toLowerCase(),p=$('#p').value,foot=$('#foot').value,st=$('#st').value,act=$('#act').value,r=e.filter(x=>(!q||x.ATLETA.toLowerCase().includes(q))&&(!p||x.POSIÇÃO===p)&&(!foot||x.PÉ===foot)&&(!st||x.STATUS===st)&&(!act||(act==='ativo'?x.STATUS!=='Transição':x.STATUS==='Transição')));$('#stbl').innerHTML=`<div class="result-count">${r.length} atleta(s) encontrado(s)</div><div class="table-wrap"><table class="table"><thead><tr><th>Foto</th><th>Atleta</th><th>Posição</th><th>Pé</th><th>Idade</th><th>Altura</th><th>Perfil</th><th>Status</th><th>Contrato</th><th>Observações</th></tr></thead><tbody>${r.map(x=>`<tr><td>${pic(x)}</td><td><b>${esc(x.ATLETA)}</b></td><td>${esc(x.POSIÇÃO)}</td><td>${esc(x.PÉ)}</td><td>${val(x,'IDADE')}</td><td>${val(x,'ALTURA')}</td><td>${val(x,'PERFIL')}</td><td>${esc(x.STATUS)}</td><td>${val(x,'CONTRATO')}</td><td>${val(x,'OBSERVAÇÕES')}</td></tr>`).join('')}</tbody></table></div>`}['s','p','foot','st','act'].forEach(id=>$('#'+id).addEventListener('input',draw));draw()}
function renderTechnical(){
  let t=D.tecnico,cols=Object.keys(t[0]||{}).filter(c=>c!=='_FOTO');
  let totalGames=t.reduce((a,r)=>a+(Number(r.JOGOS)||0),0),totalMin=t.reduce((a,r)=>a+(Number(r.MINUTOS)||0),0),totalGoals=t.reduce((a,r)=>a+(Number(r.GOLS)||0),0),totalAss=t.reduce((a,r)=>a+(Number(r['ASSIST.'])||0),0),starts=t.reduce((a,r)=>a+(Number(r.TITULAR)||0),0);
  $('#technical').innerHTML=`<div class="cards five"><div class="card"><div class="label">Jogos</div><div class="value">${totalGames||'—'}</div></div><div class="card"><div class="label">Minutos</div><div class="value">${totalMin||'—'}</div></div><div class="card"><div class="label">Gols</div><div class="value">${totalGoals||'—'}</div></div><div class="card"><div class="label">Assistências</div><div class="value">${totalAss||'—'}</div></div><div class="card"><div class="label">Titularidades</div><div class="value">${starts||'—'}</div></div></div><div class="panel"><div class="section-head"><h2>Controle técnico</h2><span>${t.length} atletas</span></div><div class="table-wrap"><table class="table technical-table"><thead><tr><th>Foto</th>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${t.map(r=>`<tr><td>${pic(r,'tech-photo')}</td>${cols.map(c=>`<td>${val(r,c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="small-note">Campos ainda não preenchidos na planilha aparecem como “—”.</div></div>`
}
function tacticalPlayer(name){
  const matches=D.elenco.filter(e=>norm(e.ATLETA)===norm(name));
  return matches.find(e=>e.STATUS==='Titular') || matches.find(e=>e.STATUS==='Ativo') || matches[0] || null;
}
function renderTactical(){
  let f=D.formation;
  $('#tactical').innerHTML=`<div class="tactical"><div class="pitch"><div class="pitch-line mid"></div><div class="pitch-circle"></div><div class="goal top"></div><div class="goal bottom"></div>${f.map(x=>{const p=tacticalPlayer(x[0]);return `<div class="player-dot" style="left:${x[1]}%;top:${x[2]}%"><div class="dot-photo">${pic(p||x[0],'tactical-photo')}</div><span>${esc(x[0])}</span></div>`}).join('')}</div><div class="panel"><div class="section-head"><h2>11 inicial · referência atual</h2><span>MAPA TÁTICO</span></div>${f.map((x,i)=>{const p=tacticalPlayer(x[0]);return `<div class="pos"><span><b>${i+1}.</b> ${esc(x[0])}</span><span>${esc(p?.POSIÇÃO||'')}</span></div>`}).join('')}<div class="bench-title">Banco / opções</div>${D.elenco.filter(e=>!f.some(x=>x[0]===e.ATLETA&&e===tacticalPlayer(x[0]))).map(x=>`<div class="pos compact"><span>${esc(x.ATLETA)}${norm(x.ATLETA)==='everton'&&x.IDADE?` · ${esc(x.IDADE)} anos`:''}</span><span>${esc(x.POSIÇÃO)}</span></div>`).join('')}</div></div>`
}
function renderPlayer(){
  let e=D.elenco;
  $('#player').innerHTML=`<div class="panel"><div class="field player-select"><label>Selecionar atleta</label><select id="sel" class="select-player">${e.map((x,i)=>`<option value="${i}">${esc(x.ATLETA)} · ${esc(x.POSIÇÃO)}${x.IDADE?` · ${esc(x.IDADE)} anos`:''} · ${esc(x.STATUS)}</option>`).join('')}</select></div><div id="pc" style="margin-top:18px"></div></div>`;
  function draw(){
    let r=e[Number($('#sel').value)]||e[0], t=D.tecnico.find(x=>x===undefined?false:x._FOTO===r.FOTO) || D.tecnico.find(x=>x.ATLETA===r.ATLETA && x.POSIÇÃO===r.POSIÇÃO && x._FOTO===r.FOTO) || D.tecnico.find(x=>x.ATLETA===r.ATLETA) || {};
    $('#pc').innerHTML=`<div class="profile"><div class="profile-head"><div class="profile-photo-frame">${pic(r,'profile-photo')}</div><div><div class="muted">${esc(r.POSIÇÃO)} · ${esc(r.PÉ)} · ${esc(r.STATUS)}</div><h2>${esc(r.ATLETA)}</h2><span class="badge">${esc(r.STATUS)}</span></div></div><div class="metric-grid">${[['Jogos','JOGOS'],['Minutos','MINUTOS'],['Gols','GOLS'],['Assistências','ASSIST.'],['Titular','TITULAR'],['Banco','BANCO']].map(x=>`<div class="metric"><b>${val(t,x[1])}</b><span>${x[0]}</span></div>`).join('')}</div><div class="grid2 profile-panels" style="margin-top:18px"><div class="panel"><h2>Dados cadastrais</h2><div class="pos"><span>Idade</span><b>${val(r,'IDADE')}</b></div><div class="pos"><span>Altura</span><b>${val(r,'ALTURA')}</b></div><div class="pos"><span>Perfil</span><b>${val(r,'PERFIL')}</b></div><div class="pos"><span>Contrato</span><b>${val(r,'CONTRATO')}</b></div></div><div class="panel"><h2>Avaliações</h2><div class="pos"><span>Técnica</span><b>${val(t,'AVALIAÇÃO TÉCNICA')}</b></div><div class="pos"><span>Tática</span><b>${val(t,'AVALIAÇÃO TÁTICA')}</b></div><div class="pos"><span>Física</span><b>${val(t,'AVALIAÇÃO FÍSICA')}</b></div><div class="pos"><span>Carga</span><b>${val(t,'CARGA')}</b></div></div></div><div class="panel obs"><h2>Controle e observações</h2><div class="pos"><span>Lesão</span><b>${val(t,'LESÃO')}</b></div><div class="pos"><span>Observações</span><b>${val(t,'OBSERVAÇÕES')}</b></div></div></div>`
  }
  $('#sel').addEventListener('change',draw);draw()
}

function renderHistory(){
  const h=D.historico||[];
  const returning=h.filter(r=>norm(r["OBSERVAÇÃO"]).includes('voltando de lesao')).length;
  const active=h.filter(r=>r.ATIVO_ATUAL===true).length;
  const titles=h.filter(r=>r["TÍTULOS"]&&r["TÍTULOS"]!=="-").length;
  $('#history').innerHTML=`
    <div class="cards four">
      <div class="card"><div class="label">Atletas com histórico</div><div class="value">${h.length}</div></div>
      <div class="card"><div class="label">Voltando de lesão</div><div class="value">${returning}</div></div>
      <div class="card card-active"><div class="label">Ativos em competição</div><div class="value">${active}</div></div>
      <div class="card"><div class="label">Atletas com títulos</div><div class="value">${titles}</div></div>
    </div>
    <div class="panel history-panel">
      <div class="filterbar history-filters">
        <div class="field"><label>Buscar atleta</label><input id="hs" placeholder="Nome..."></div>
        <div class="field"><label>Posição</label><select id="hp"><option value="">Todas</option>${[...new Set(h.map(x=>x["POSIÇÃO"]))].map(x=>`<option>${esc(x)}</option>`).join('')}</select></div>
        <div class="field"><label>Minutagem 2026</label><select id="hsort"><option value="">Sem ordenação</option><option value="desc">Maior → menor</option><option value="asc">Menor → maior</option></select></div>
      </div>
      <div class="history-note">A ordenação abaixo considera exclusivamente a minutagem de 2026. Os nomes destacados em cinza correspondem aos atletas que estão atuando em uma competição atual. Os links do Ogol abrem diretamente a página do atleta e o campo “Últimos 10 jogos” está preparado para receber o link do Drive.</div>
      <div id="hcontent"></div>
    </div>`;
  function draw(){
    const q=norm($('#hs').value), p=$('#hp').value, sort=$('#hsort').value;
    let rows=h.filter(r=>(!q||norm(r.ATLETA).includes(q))&&(!p||r["POSIÇÃO"]===p));
    const minutes=v=>{const n=Number(String(v??'').replace(',','.'));return Number.isFinite(n)?n:-1};
    if(sort==='desc') rows.sort((a,b)=>minutes(b["MINUTAGEM 2026"])-minutes(a["MINUTAGEM 2026"]));
    if(sort==='asc') rows.sort((a,b)=>minutes(a["MINUTAGEM 2026"])-minutes(b["MINUTAGEM 2026"]));
    $('#hcontent').innerHTML=`
      <div class="result-count">${rows.length} atleta(s) encontrado(s)</div>
      <div class="table-wrap history-table-wrap"><table class="table history-table">
        <thead><tr>
          <th>Foto</th><th>Atleta</th><th>Posição</th>
          <th>Min. 2026</th><th>J. Rel. 2026</th><th>J. Disp. 2026</th><th>Últ. jogo</th>
          <th>Min. 2025</th><th>J. Rel. 2025</th><th>J. Disp. 2025</th>
          <th>Títulos</th><th>Rebaixamento</th><th>Observação</th><th>Ogol</th><th>Últimos 10 jogos</th>
        </tr></thead>
        <tbody>${rows.map(r=>{
          const activeClass=r.ATIVO_ATUAL?' current-active':'';
          const activeName=r.ATIVO_ATUAL?`<span class="current-active-name">${esc(r.ATLETA)}</span>`:esc(r.ATLETA);
          const titles=r["TÍTULOS"]?`<details><summary>Ver</summary><div class="history-text">${esc(r["TÍTULOS"]).replace(/\n/g,'<br>')}</div></details>`:'—';
          const releg=r["REBAIXAMENTO"]?`<div class="history-text">${esc(r["REBAIXAMENTO"]).replace(/\n/g,'<br>')}</div>`:'—';
          const obs=r["OBSERVAÇÃO"]?`<div class="history-text">${esc(r["OBSERVAÇÃO"]).replace(/\n/g,'<br>')}</div>`:'—';
          const og=r.OGOL?`<a class="link-btn" href="${esc(r.OGOL)}" target="_blank" rel="noopener noreferrer">Abrir Ogol ↗</a>`:'—';
          const drive=r.DRIVE?`<a class="link-btn drive" href="${esc(r.DRIVE)}" target="_blank" rel="noopener noreferrer">Abrir Drive ↗</a>`:`<span class="link-pending">Aguardando link</span>`;
          return `<tr class="${activeClass}">
            <td>${pic({ATLETA:r.ATLETA,FOTO:r.FOTO},'history-photo')}</td>
            <td><b>${activeName}</b></td><td>${esc(r["POSIÇÃO"])}</td>
            <td>${val(r,"MINUTAGEM 2026")}</td><td>${val(r,"JOGOS RELACIONADO 2026")}</td><td>${val(r,"JOGOS DISPUTADO 2026")}</td><td>${val(r,"ÚLTIMO JOGO (atuando)")}</td>
            <td>${val(r,"MINUTAGEM 2025")}</td><td>${val(r,"JOGOS RELACIONADO 2025")}</td><td>${val(r,"JOGOS DISPUTADO 2025")}</td>
            <td>${titles}</td><td>${releg}</td><td>${obs}</td><td>${og}</td><td>${drive}</td>
          </tr>`}).join('')}</tbody>
      </table></div>`;
  }
  ['hs','hp','hsort'].forEach(id=>$('#'+id).addEventListener('input',draw));
  draw();
}

const titles={overview:'Visão Geral',squad:'Elenco',technical:'Controle Técnico',tactical:'Mapa Tático',player:'Fichas do Atleta',history:'Histórico'};
document.querySelectorAll('.nav-btn').forEach(b=>b.onclick=()=>{document.querySelectorAll('.nav-btn').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$('#'+b.dataset.page).classList.add('active');$('#pageTitle').textContent=titles[b.dataset.page];scrollTo(0,0)});
fetch('data.json').then(r=>r.json()).then(x=>{D=x;const tm=$('#topMeta');if(tm)tm.textContent=`Elenco atual · ${D.elenco.length} atletas`;renderOverview();renderSquad();renderTechnical();renderTactical();renderPlayer();renderHistory()}).catch(()=>document.querySelector('.main').innerHTML='<div class="panel empty">Erro ao carregar os dados.</div>');
